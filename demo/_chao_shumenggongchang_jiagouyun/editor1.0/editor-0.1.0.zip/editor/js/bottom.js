var copyright = new Date();
update = copyright.getFullYear();
document.writeln("<div id='footer'>");
document.writeln("<p class=\"footer-p\">");
document.writeln("Copyright &copy; 2004-"+ update + " Serva Software | 沪ICP备10200962号   ");
document.writeln("</p>");
document.writeln("</div> ");
