document.writeln("<div id = 'top'>");
document.writeln("<img src='./images/logo.png' alt='Editor' id='top-logo'><span>Editor</span>");
document.writeln("<div><span></span><div class='header'></div></div>");
document.writeln("</div>");